import validators

from http import HTTPStatus
from flask import Flask, request

from .core import remove_vhost, add_vhost
from .scheduler import Scheduler
from .logger import logger

# Flask app
app = Flask(__name__)
scheduler = Scheduler()


@app.route('/')
def index():
    return "It works!"


@app.route('/vhosts/<domain>/add', methods=['POST'])
def add(domain):
    if not validators.domain(domain):
        return {"success": False, "error": "Invalid domain"}, HTTPStatus.BAD_REQUEST

    content = request.get_json(force=True)

    callback = content.get("callback")
    url = content.get("url")
    proxy_pass = content.get("proxy_pass")
    auth = content.get("auth")
    api_key = content.get("api_key")
    api_key_header = content.get("api_key_header")

    if not proxy_pass:
        return {"success": False, "error": "[proxy_pass] must be present"}, HTTPStatus.BAD_REQUEST

    if callback:
        if not url:
            return {"success": False, "error": "[url] must be present"}, HTTPStatus.BAD_REQUEST

        if auth:
            if not api_key or not api_key_header:
                return {"success": False, "error": "[api_key, api_key_header] must be present"}, HTTPStatus.BAD_REQUEST

    try:
        if callback:
            scheduler.add_vhost(domain, proxy_pass, callback, url, auth, api_key_header, api_key)
        else:
            add_vhost(domain, proxy_pass, callback, url, auth, api_key_header, api_key)
    except Exception as e:
        logger.debug(e)
        return {"success": False, "error": f"{e}"}

    return {"success": True, "msg": f"Added {domain} vhost"}


@app.route('/vhosts/<domain>/remove', methods=['DELETE'])
def remove(domain):
    if not validators.domain(domain):
        return {"success": False, "error": "Invalid domain"}, HTTPStatus.BAD_REQUEST
    try:
        remove_vhost(domain)
    except Exception as e:
        logger.debug(e)
        return {"success": False, "error": e}, HTTPStatus.BAD_REQUEST

    return {"success": True, "msg": f"Removed {domain} vhost"}
