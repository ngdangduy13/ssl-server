from datetime import datetime, timedelta

from concurrent.futures import ThreadPoolExecutor
from apscheduler.schedulers.background import BackgroundScheduler

from .config import *
from .core import reload_nginx, add_vhost
from .logger import logger


def setup_vhost(domain, proxy_pass, callback, url, auth, api_key_header, api_key):
    try:
        add_vhost(domain, proxy_pass, callback, url, auth, api_key_header, api_key)
    except Exception as e:
        logger.debug(e)
        return False

    return True


class Scheduler:
    def __init__(self):
        # https://apscheduler.readthedocs.io/en/latest/userguide.html#configuring-the-scheduler
        self.scheduler = BackgroundScheduler({
            "apscheduler.executors.default": {
                "class": "apscheduler.executors.pool:ThreadPoolExecutor",
                "max_workers": "2"
            }
        })

        self.executor = ThreadPoolExecutor(4)
        self.scheduler.start()

    def reload_nginx(self):
        logger.debug("Request reload nginx")
        scheduled_job = self.scheduler.get_job(RELOAD_NGINX_ASYNC_TASK_ID)

        if scheduled_job:
            logger.debug(f"The reloading nginx scheduler at {scheduled_job.next_run_time} was cancelled")
            scheduled_job.remove()

        run_date = datetime.now() + timedelta(seconds=RELOAD_NGINX_DELAY)
        self.scheduler.add_job(reload_nginx, "date", run_date=run_date, id=RELOAD_NGINX_ASYNC_TASK_ID)

        logger.debug(f"Scheduled to reload nginx at {run_date}")

    def add_vhost(self, domain, proxy_pass, callback, url, auth, api_key_header, api_key):
        logger.debug(f"Start add {domain} vhost async")
        logger.info("Start adding {} vhost async", domain)

        async_task = self.executor.submit(setup_vhost, domain, proxy_pass, callback, url, auth, api_key_header, api_key)
        async_task.add_done_callback(self.add_vhost_done_callback)

    def add_vhost_done_callback(self, future):
        try:
            # https://docs.python.org/3/library/concurrent.futures.html
            status = future.result(timeout=2)
        except Exception as e:
            logger.debug(e)
            status = False

        if status:
            self.reload_nginx()
