import sys
from loguru import logger

logger.remove(0)
logger.add(sys.stdout, format="{time:YYYY-MM-DD HH:mm:ss ZZ} | {level} | {message}",
           level="TRACE", backtrace=False, diagnose=False, catch=True, colorize=True)
