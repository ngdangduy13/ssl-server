import os
import click
import subprocess


def confirm_overwrite_file(file):
    msg = f"{file} is already existing, Do you want to overwrite it?"
    if os.path.exists(file):
        return click.confirm(msg, show_default=True, default=False)

    return True


def write_file(file, content):
    if not confirm_overwrite_file(file):
        return

    with open(file, "w+") as f:
        f.write(content)
        f.close()


def run_subprocess(cmd_str):
    result = subprocess.run(cmd_str, shell=True)
    if result.returncode != 0:
        raise click.ClickException(f"Failed to execute command: '{cmd_str}'")


def run_subprocess_silent(cmd_str):
    result = subprocess.run(cmd_str, shell=True)
    return result.returncode == 0


def run_subprocess_capture_output(cmd_str):
    result = subprocess.run(cmd_str, shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        raise click.ClickException(result.stderr)
    return result.stdout


def rm(file):
    if os.path.exists(file):
        os.unlink(file)
