import re
import click
import requests
from textwrap import dedent

from .config import *
from .logger import logger

from .util import write_file, confirm_overwrite_file, rm
from .util import run_subprocess, run_subprocess_silent, run_subprocess_capture_output


def install_acme(email):
    logger.debug("Install acme.sh")

    if not confirm_overwrite_file(ACME):
        return

    # Download and install acme.sh
    cmd_str = f"curl https://get.acme.sh | sh -s email={email}"
    run_subprocess(cmd_str)

    # Create soft link /usr/local/bin/certbot-nginx
    run_subprocess(f"ln -sf {HOME_DIR}/bin/certbot-nginx /usr/local/bin/certbot-nginx")
    logger.debug("Install acme.sh => DONE")


def configure_nginx(email):
    logger.debug("Configure nginx")

    # Create /etc/nginx/certs folder
    run_subprocess(f"mkdir -p {CERT_DIR}")

    # Create /etc/nginx/snippets/db_param.pem
    create_dh_param_file()

    # Configure stateless challenge
    configure_stateless_mode_acme(ZERO_SSL, email)

    # Reload
    reload_nginx()
    logger.debug("Configure nginx => DONE")


def setup_systemctl_service(host, port):
    service_conf = dedent("""
        [Unit]
        Description=Certbot-Nginx Rest API Server
        After=network.target

        [Service]
        Type=simple
        User=root
        WorkingDirectory=%s
        ExecStart=%s/bin/certbot-nginx start-api-server --host %s --port %d
        Restart=always
        
        StandardOutput=append:%s
        StandardError=append:%s

        [Install]
        WantedBy=multi-user.target
    """ % (HOME_DIR, HOME_DIR, host, port, LOG_FILE, LOG_FILE)).strip("\n")

    logger.debug(f"Modify {SERVICE_CONF_FILE} to configure systemctl service")
    write_file(SERVICE_CONF_FILE, service_conf)

    cmd_str = "systemctl daemon-reload && systemctl enable certbot-nginx && systemctl restart certbot-nginx"
    run_subprocess_silent(cmd_str)


def create_dh_param_file():
    if not confirm_overwrite_file(DH_PARAM_FILE):
        return

    cmd_str = f"openssl dhparam -out {DH_PARAM_FILE} 2048"
    run_subprocess(cmd_str)


def configure_stateless_mode_acme(server, email):
    logger.debug("Configure acme stateless mode")

    cmd_str = f"{ACME} --register-account --server {server} --email {email}"
    result = run_subprocess_capture_output(cmd_str)

    logger.debug(result)
    account_thumbprint = re.search(r"ACCOUNT_THUMBPRINT=\'([-_a-zA-Z0-9]+)\'", result).group(1)
    default_conf = dedent("""
        server {
            listen 80 default_server;
            listen [::]:80 default_server;

            server_name _;

            location ~ ^/\\.well-known/acme-challenge/([-_a-zA-Z0-9]+)$ {
                default_type text/plain;
                return 200 "$1.%s";
            }
            
            location / {
                return 301 https://$host$request_uri;
            }
        }
    """ % account_thumbprint).strip("\n")

    logger.debug(f"Modify {DEFAULT_CONF_FILE} to configure stateless mode acme")
    write_file(DEFAULT_CONF_FILE, default_conf)

    logger.debug("Configure acme stateless mode => DONE")


def reload_nginx():
    logger.debug("Reload nginx")

    cmd_str = "nginx -s reload"
    run_subprocess_silent(cmd_str)


def issue_cert(domain):
    logger.debug(f"Issue SSL for {domain}")

    cmd_str = f"{ACME} --issue --stateless --domain {domain} --force"
    if not run_subprocess_silent(cmd_str):
        logger.debug(f"Failed to issue SSL for {domain}")
        raise click.ClickException(f"Failed to issue SSL for {domain}")

    logger.debug(f"Issue SSL for {domain} => DONE")


def renew_cert(domain, force, reload=False):
    if domain:
        logger.debug(f"Renew SSL for {domain}")

        cmd_str = f"{ACME} --renew --domain {domain} {force}"
        if not run_subprocess_silent(cmd_str):
            logger.debug(f"Failed to renew SSL for {domain}")
            raise click.ClickException(f"Failed to renew SSL for {domain}")

        logger.debug(f"Renew SSL for {domain} => DONE")
    else:
        logger.debug(f"Renew SSL")

        cmd_str = f"{ACME} --renew-all {force}"
        if not run_subprocess_silent(cmd_str):
            logger.debug("Failed to issue SSL")
            raise click.ClickException(f"Failed to renew ALL SSL")

        logger.debug(f"Renew SSL => DONE")

    if reload:
        reload_nginx()


def install_cronjob():
    logger.debug("Install cronjob to renew certs")

    cmd_str = f"{ACME} --install-cronjob"
    if not run_subprocess_silent(cmd_str):
        logger.debug("Failed to install cronjob")
        raise click.ClickException("Failed to install cronjob")

    logger.debug("Install cronjob to renew certs => DONE")


def install_cert(domain):
    logger.debug(f"Install SSL for {domain}")
    run_subprocess_silent(f"mkdir -p {CERT_DIR}/{domain}")

    ssl_certificate = f"{CERT_DIR}/{domain}/cert.pem"
    ssl_certificate_key = f"{CERT_DIR}/{domain}/key.pem"

    cmd_str = (f"{ACME} --install-cert --domain {domain}"
               f" --key-file {ssl_certificate_key} --fullchain-file {ssl_certificate}")
    if not run_subprocess_silent(cmd_str):
        logger.debug(f"Failed to install SSL for {domain}")
        raise click.ClickException(f"Failed to install SSL for {domain}")

    logger.debug(f"Install SSL for {domain} => DONE")
    return ssl_certificate, ssl_certificate_key


def add_vhost(domain, proxy_pass, callback, url, auth, api_key_header, api_key,
              hosted=None, webroot=None, reload=False):
    logger.debug(f"Add {domain} vhost")

    # Check
    if hosted:
        if not webroot:
            raise click.ClickException(f"--webroot is required by --hosted")
    else:
        if not proxy_pass:
            raise click.ClickException(f"--proxy-pass is required by --no-hosted")

    if callback:
        if not url:
            raise click.ClickException(f"--url is required by --callback")
        if auth and (not api_key or not api_key_header):
            raise click.ClickException(f"--api-key, --api-key-header is require by --auth")

    try:
        # Setup SSL
        issue_cert(domain)
        ssl_certificate, ssl_certificate_key = install_cert(domain)

        # Add config
        if hosted:
            add_hosted_vhost(domain, ssl_certificate, ssl_certificate_key, webroot)
        else:
            add_proxy_vhost(domain, ssl_certificate, ssl_certificate_key, proxy_pass)

        # Reload
        if reload:
            reload_nginx()

        # Send callback
        send_callback(domain, STATUS_SUCCESS, callback, url, auth, api_key_header, api_key)
    except Exception as error:
        # Send callback
        send_callback(domain, STATUS_FAIL, callback, url, auth, api_key_header, api_key)

        # Raise exception
        raise error


def remove_vhost(domain, reload=False):
    logger.debug(f"Remove {domain} vhost")

    # Revoke
    cmd_str = f"{ACME} --remove --domain {domain}"
    run_subprocess_silent(cmd_str)

    # Remove
    rm(f"{CERT_DIR}/{domain}")
    rm(f"{CONF_DIR}/{domain}.conf")

    # Reload
    if reload:
        reload_nginx()


def add_hosted_vhost(domain, ssl_certificate, ssl_certificate_key, webroot):
    server_name = domain
    dh_param = DH_PARAM_FILE

    conf_file = f"{CONF_DIR}/{domain}.conf"
    conf = dedent("""
            server {
                listen 443 ssl http2;
                listen [::]:443 ssl http2;
            
                server_name %s;

                ssl_certificate %s;
                ssl_certificate_key %s;
                
                root %s;
                index index.html index.htm;

                location / {
                    try_files $uri $uri/ /index.html =404;
                }

                ssl_session_cache shared:le_nginx_SSL:10m;
                ssl_session_timeout 1440m;
                ssl_session_tickets off;

                ssl_protocols TLSv1.2 TLSv1.3;
                ssl_prefer_server_ciphers off;

                ssl_ciphers "ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384";
                ssl_dhparam %s;
            }
        """ % (server_name, ssl_certificate, ssl_certificate_key, webroot, dh_param)).strip("\n")

    with open(conf_file, "w+") as f:
        f.write(conf)
        f.close()


def add_proxy_vhost(domain, ssl_certificate, ssl_certificate_key, proxy_pass):
    server_name = domain
    dh_param = DH_PARAM_FILE

    conf_file = f"{CONF_DIR}/{domain}.conf"
    conf = dedent("""
        server {
            listen 443 ssl http2;
            listen [::]:443 ssl http2;
        
            server_name %s;

            ssl_certificate %s;
            ssl_certificate_key %s;

            location / {
                proxy_pass                          %s;
                proxy_set_header  Host              $http_host;
                proxy_set_header  X-Real-IP         $remote_addr;
                proxy_set_header  X-Forwarded-For   $proxy_add_x_forwarded_for;
                proxy_set_header  X-Forwarded-Proto $scheme;
                proxy_read_timeout                  900;
            }
            
            ssl_session_cache shared:le_nginx_SSL:10m;
            ssl_session_timeout 1440m;
            ssl_session_tickets off;
            
            ssl_protocols TLSv1.2 TLSv1.3;
            ssl_prefer_server_ciphers off;
            
            ssl_ciphers "ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384";
            ssl_dhparam %s;
        }
    """ % (server_name, ssl_certificate, ssl_certificate_key, proxy_pass, dh_param)).strip("\n")

    with open(conf_file, "w+") as f:
        f.write(conf)
        f.close()


def send_callback(domain, status, callback, url, auth, api_key_header, api_key):
    if not callback:
        return

    logger.debug(f"Send callback to {url} ({domain}={status})")
    try:
        content = {
            "domain": domain,
            "success": status
        }

        headers = {
            "Content-Type": "application/json",
            "User-Agent": f"{NAME}/{VERSION}"
        }
        if auth:
            headers[api_key_header] = api_key

        requests.post(url, json=content, headers=headers, timeout=30)
        logger.debug(f"Send callback to {url} ({domain}={status}) => DONE")
    except Exception as error:
        logger.debug(error)
        logger.debug(f"Failed to send callback to {url}")
