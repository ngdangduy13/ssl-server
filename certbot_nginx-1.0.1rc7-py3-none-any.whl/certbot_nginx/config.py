NAME = "certbot-nginx"
VERSION = "1.0.1-rc7"

# Nginx
CERT_DIR = "/etc/nginx/certs"
CONF_DIR = "/etc/nginx/sites-enabled"

DH_PARAM_FILE = f"{CERT_DIR}/dh_param.pem"
DEFAULT_CONF_FILE = f"{CONF_DIR}/default"

SERVICE_CONF_FILE = "/etc/systemd/system/certbot-nginx.service"
LOG_FILE = "/var/log/certbot-nginx.log"

# ACME
ACME = "/root/.acme.sh/acme.sh"
HOME_DIR = "/root/.certbot-nginx"

# CA providers
ZERO_SSL = "zerossl"
LETS_ENCRYPT = "letsencrypt"

# Defaults
DEFAULT_EMAIL = "huytd92@gmail.com"
DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 5000

# Consts
STATUS_SUCCESS = "succeed"
STATUS_FAIL = "failed"

# ID
RELOAD_NGINX_ASYNC_TASK_ID = "nginx-reload-async-task"
RELOAD_NGINX_DELAY = 120
