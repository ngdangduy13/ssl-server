import os
import click
from waitress import serve

from .config import *
from .api import app
from .core import install_acme, configure_nginx, setup_systemctl_service, install_cronjob
from .core import add_vhost, remove_vhost, renew_cert


@click.group()
@click.version_option(VERSION)
def main():
    if os.getuid() != 0:
        raise click.ClickException("Only root privilege can perform this action!")


@main.command(name="setup")
@click.option("--email", prompt="Register account (email)", default=DEFAULT_EMAIL)
@click.option("--host", prompt="API server host", default=DEFAULT_HOST)
@click.option("--port", prompt="API server port", default=DEFAULT_PORT)
@click.option("--api-server", prompt="Start API server", default=True, is_flag=True)
def cli_setup(email, host, port, api_server):
    """ Wizard setup
    """
    install_acme(email)
    configure_nginx(email)

    if api_server:
        setup_systemctl_service(host, port)


@main.command(name="add-vhost")
@click.option("--domain", required=True, help="Specifies a domain")
@click.option("--proxy-pass", default=None, help="Backend upstream server for proxying requests")
@click.option("--callback/--no-callback", default=False, is_flag=True, help="Enable callback")
@click.option("--url", default=None, help="Callback URL, only valid for the '--callback'")
@click.option("--auth/--no-auth", default=False, is_flag=True, help="Is callback api needed auth?")
@click.option("--api-key-header", default=None, help="API key header, only valid for the '--auth'")
@click.option("--api-key", default=None, help="API key, only valid for the '--auth'")
@click.option("--hosted/--no-hosted", default=False, is_flag=True, help="Is hosted vhost?")
@click.option("--webroot", default=None,
              help="Specifies the web root folder for web root mode, only valid for the '--hosted'")
@click.option("--reload/--no-reload", default=True, is_flag=True, help="Reload nginx")
def cli_add_vhost(domain, proxy_pass, callback, url, auth, api_key_header, api_key, hosted, webroot, reload):
    """ Add vhost

    \b
    $ certbot-nginx add-vhost --domain <domain> --proxy-pass <backend-upstream-server>
    $ certbot-nginx add-vhost --domain <domain> --proxy-pass <backend-upstream-server> --callback --url <callback-url>
    $ certbot-nginx add-vhost --domain <domain> --proxy-pass <backend-upstream-server> --callback --url <callback-url>
        --auth --api-key-header <header> --api-key <key>
    $ certbot-nginx add-vhost --domain <domain> --hosted --webroot <directory>
    """
    add_vhost(domain, proxy_pass, callback, url, auth, api_key_header, api_key, hosted, webroot, reload)


@main.command(name="remove-vhost")
@click.option("--domain", required=True, help="Specifies a domain")
@click.option("--reload/--no-reload", default=True, is_flag=True, help="Reload nginx")
def cli_remove_vhost(domain, reload):
    """ Remove vhost
    """
    remove_vhost(domain, reload)


@main.command(name="renew")
@click.option("--domain", default=None, help="Specifies a domain (If not present => all certs will be renewed)")
@click.option("--force", is_flag=False, flag_value="--force", default="")
@click.option("--reload/--no-reload", default=True, is_flag=True, help="Reload nginx")
def cli_renew_cert(domain, force, reload):
    """ Renew cert(s)

    \b
    $ certbot-nginx renew --domain <domain>
    $ certbot-nginx renew --domain <domain> --force
    $ certbot-nginx renew
    $ certbot-nginx renew --force
    """
    renew_cert(domain, force, reload)


@main.command(name="install-cronjob")
def cli_install_cronjob():
    """ Install cronjob to renew certs
    """
    install_cronjob()


@main.command(name="start-api-server")
@click.option("--host", default=DEFAULT_HOST, show_default=True, help="Host binding")
@click.option("--port", default=DEFAULT_PORT, show_default=True, help="Port")
def cli_start_api_server(host, port):
    """ Start Rest API server
    """
    start_api_server(host, port)


def start_api_server(host, port):
    click.echo(f"Serving API on http://{host}:{port}/")
    serve(app, host=host, port=port)


if __name__ == "__main__":
    main()
